#!/bin/sh

sudo dnf install akmod-nvidia nvidia-settings xorg-x11-drv-nvidia xorg-x11-drv-nvidia-libs


sudo dnf install nvidia-persistenced xorg-x11-drv-nvidia-cuda xorg-x11-drv-nvidia-cuda-libs


